# ![logo](src/LINE.png) LINE Js-kicker

Dangerous ⚠ Use it at your own risk !


How to run ?
------
- `git clone https://github.com/a040900/Js-kicker`
- `cd Js-kicker && npm install`
- `cd src`
- `npm start`
- `type av8drun -> kick all member`

----
**NOTE & Features** 
- Don't forget to put your mid in main.js 'myBot'
- Delete unuseful code 
- Improve logic
----

*Fork From* [here](https://github.com/rnjacky777/785)

## Fix and upload by 
[@author](https://line.me/ti/p/3eamxoks_T)
